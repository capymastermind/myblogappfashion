from django import forms
from django.contrib.auth.forms import AuthenticationForm

class LoginForm(AuthenticationForm):
 name = forms.CharField(label='Your Name', max_length=100)
email = forms.EmailField(label='Your Email', max_length=100)
age = forms.IntegerField(label='Your Age')
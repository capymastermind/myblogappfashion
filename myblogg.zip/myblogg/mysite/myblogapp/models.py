from django.db import models
from django.db.models import Model
class Myblogapp(models.Model):
    text = models.CharField(max_length=200)
    created_date=models.DateTimeField()

    def _str_(self):
        return self.text
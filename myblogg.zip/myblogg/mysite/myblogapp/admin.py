from django.contrib import admin
from myblogapp.models import Myblogapp
class BlogAdmin(admin.ModelAdmin):
    list_display=('text','created_date')
admin.site.register(Myblogapp,BlogAdmin)
# Register your models here.

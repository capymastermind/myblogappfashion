from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm


def home(request):
    context={}
    return render(request, "myblogapp/home.html", context )
from django.shortcuts import render
def landing_page_view(request,*args,**kwargs):
       return render(request, 'myblogapp/landing_page.html',{}) 
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from .forms import LoginForm
def login_view(request):
       if request.method == 'POST':
           form = LoginForm(request, request.POST)
           if form.is_valid():
               user = form.get_user()
               login(request, user)
               # Redirect to a success page or home page after login
               return redirect('landing_page')
       else:
           form = LoginForm()

       return render(request, "myblogapp/login_page.html", {'form': form})




from django.contrib import admin
from django.urls import path,include
admin.site.site_header="FASHION HAUL"
admin.site.index_title="COLLECTIONS"
admin.site.site_title="hello index T"


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include("myblogapp.urls")),
    path('accounts/', include('django.contrib.auth.urls')),
]
